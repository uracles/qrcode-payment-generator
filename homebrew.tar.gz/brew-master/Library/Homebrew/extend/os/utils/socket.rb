# typed: strict
# frozen_string_literal: true

require "extend/os/mac/utils/socket" if OS.mac?
